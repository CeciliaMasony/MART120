
var x=180;
var xDirection = "right";
var xSpeed;

var y=180;
var yDirection = "down";
var ySpeed;

var x1=100;
var x1Direction = "right";
var x1Speed;

var y1=100;
var y1Direction = "up";
var y1Speed;

var size = 45;
var count = 0;
var sizeDirection = 1;


function setup() {
  createCanvas(500,600);
  xSpeed = random (1,5);
  ySpeed = random (1,5);
  x1Speed = random(1,5);
  y1Speed = random (1,5);
}


function draw() {
  background(140,190,250);
  strokeWeight(4);

  //left arm
  line(40,y,113,260);

  //right arm
  line(x,260,300,160);

  //head
  fill("beige");
  circle(x, y, y);

  fill("white");
  circle(145, y, 55);
  circle(x, 90, 55);

  //body
  fill("green");
  rect(155,y,50,50);
  rect(x,280,130,150);
  point(145,95);
  point(220,95);

  //mouth
  fill("pink");
  triangle(190,150,150,145,160,165);

  //text
  fill("purple");
  textSize(size);
  size+=sizeDirection;
  count++;
  if (count>5) {
    sizeDirection*=-1;
    count=0;
  }
    text("CECILIA",x1,y1);



  if (x1Direction=="right") {
    x1=x1+x1Speed;
  }

  
  if (y1Direction=="up") {
    y1=y1+y1Speed;
  }

 
  if (x1Direction=="left") {
    x1=x1-x1Speed;
  }

  if (y1Direction=="down") {
    y1=y1-y1Speed;
  }


  if (x1>=350 && y1<=100) {
    x1Direction="left";
    y1Direction="up";
  }

  if (x1>=350 && y1>=300) {
    x1Direction="left";
    y1Direction="down";
  }

  if (x1<=100 && y1>=300) {
    x1Direction="right";
    y1Direction="up";
  }

  if (x1<=100 && y1<=300) {
    x1Direction="right";
    y1Direction="none";
  }
 if (xDirection=="right"){
  x=x + xSpeed;
  }
    
  if (xDirection=="left") {
    x=x - xSpeed;
  }
    
  if (x>=450) {
     xDirection = "left";
     xSpeed = random(1,5);
  }
    
  if (x<=0) {
    xDirection = "right";
    xSpeed = random(1, 5);
  }

if (yDirection=="up"){
  y=y + ySpeed;
  }
  if (yDirection=="down") {
    y=y - ySpeed;
  }
    
  if (y>=195) {
     yDirection = "down";
     ySpeed = random(1,10);     
  }
    
  if (y<=-10) {
    yDirection = "up";
    ySpeed = random(1,10);
  }
 }